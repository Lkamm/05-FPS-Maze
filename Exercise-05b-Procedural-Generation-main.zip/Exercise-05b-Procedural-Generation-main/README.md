# Exercise-05b-Procedural-Generation

Exercise for MSCH-C220

An implementation of a procedurally-generated 3D maze. Also, a simple in-game menu.

## Implementation

Built using Godot 3.5

## References

This project is an adaptation of the excellent tutorial from [KidsCanCode](https://kidscancode.org/blog/2018/08/godot3_procgen1/)

## Future Development

None

## Created by 

Garrett Biggs
```
